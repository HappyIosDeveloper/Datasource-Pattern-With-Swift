//
//  ViewController.swift
//  Datasource Pattern
//
//  Created by Ahmadreza on 7/17/22.
//

import UIKit

class ViewController: UIViewController {

    let customView = CustomView(frame: CGRect(origin: CGPoint(x: 20, y: 100), size: CGSize(width: UIScreen.main.bounds.width - 40, height: 300)))
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.addSubview(customView)
        customView.dataSource = self
        customView.loadData()
    }
}

extension ViewController: CustomViewDataSource {
    
    func customViewLabelTextProvider() -> String {
        return "Hello this is a text"
    }
    
    func customViewBackgroundColorProvider() -> UIColor {
        return .blue
    }
}
