//
//  CustomView.swift
//  Datasource Pattern
//
//  Created by Ahmadreza on 7/17/22.
//

import UIKit

protocol CustomViewDataSource: AnyObject {
    func customViewLabelTextProvider()-> String
    func customViewBackgroundColorProvider()-> UIColor
}

class CustomView: UIView {
    
    private var label = UILabel()
    private var button = UIButton()
    weak var dataSource: CustomViewDataSource?
    
    func loadData() {
        let width = frame.size.width
        label = UILabel(frame: CGRect(origin: .zero, size: CGSize(width: width, height: 40)))
        addSubview(label)
        if let tex = dataSource?.customViewLabelTextProvider() {
            label.text = tex
        }
        button = UIButton(frame: CGRect(origin: CGPoint(x: (width / 2) - 100, y: 60), size: CGSize(width: 200, height: 40)))
        addSubview(button)
        button.setTitle("button", for: .normal)
        if let color = dataSource?.customViewBackgroundColorProvider() {
            button.backgroundColor = color
        }
    }
}
